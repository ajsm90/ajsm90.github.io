# import requests
# import xbmcgui
# from bs4 import BeautifulSoup
# from urllib.parse import urljoin
# from concurrent.futures import ThreadPoolExecutor, as_completed

# def mostrar_notificacion(titulo, mensaje, duracion=3000):
#     xbmcgui.Dialog().notification(titulo, mensaje, time=duracion, sound=False)

# def obtener_series(pagina=1):

#     mostrar_notificacion("Actualizando lista, espera a que termine", "Obteniendo series...", 3000)
#     """Obtiene el listado de series en la página especificada."""
#     base_url = "https://dontorrent.fashion"
#     url = f"{base_url}/series/page/{pagina}"
#     series = []

#     response = requests.get(url)
#     soup = BeautifulSoup(response.content, "html.parser")

#     # Encontrar todos los enlaces <a> que contienen una imagen <img>
#     links = [(link['href'], urljoin("https:", link.find("img")["src"])) 
#              for link in soup.find_all("a", href=True) if link.find("img")]

#     with ThreadPoolExecutor(max_workers=10) as executor:
#         future_to_url = {executor.submit(obtener_datos_serie, urljoin(base_url, href)): (href, img_src) for href, img_src in links}
        
#         for future in as_completed(future_to_url):
#             href, img_src = future_to_url[future]
#             try:
#                 title, description = future.result()
#                 if title:  
#                     series.append({
#                         "titulo": title,
#                         "imagen": img_src,
#                         "descripcion": description,
#                         "url": urljoin(base_url, href)
#                     })
#             except Exception as e:
#                 print(f"Error procesando {href}: {e}")

#     return series

# def obtener_datos_serie(series_url):
#     """Obtiene el título y la descripción de una serie a partir de su URL."""
#     series_response = requests.get(series_url)
#     series_soup = BeautifulSoup(series_response.content, "html.parser")
    
#     title_tag = series_soup.find("h2", class_="descargarTitulo")
#     title = title_tag.get_text(strip=True) if title_tag else ""
#     title = title.replace("Descargar ", "").replace(" por Torrent", "").strip()
    
#     description_tag = series_soup.find("p", class_="text-justify")
#     description = ""
#     if description_tag and description_tag.find("b", class_="bold").get_text(strip=True) == "Descripción:":
#         description = description_tag.get_text(strip=True).replace("Descripción:", "").strip()

#     return title, description

# def obtener_episodios_serie(series_url):
#     """Obtiene la lista de episodios de una serie específica."""
#     series_response = requests.get(series_url)
#     series_soup = BeautifulSoup(series_response.content, "html.parser")
    
#     episodes = []
#     episode_table = series_soup.find("table")  
#     if episode_table:
#         for row in episode_table.find_all("tr"):
#             cells = row.find_all("td")
#             if len(cells) >= 3:  
#                 episode = cells[0].get_text(strip=True) 
                
#                 download_link = cells[1].find("a")["href"] if cells[1].find("a") else ""
#                 if download_link and not download_link.startswith("http"):
#                     download_link = f"https://{download_link.lstrip('/')}"

#                 date = cells[2].get_text(strip=True)  # Fecha del episodio
#                 episodes.append({
#                     "capitulo": episode,
#                     "enlace_descarga": download_link,
#                     "fecha": date
#                 })

#     return episodes

# def buscar_serie(titulo_busqueda):
#     """Busca series por título en https://dontorrent.fashion/buscar/ y retorna los resultados con imagen."""
#     url_busqueda = f"https://dontorrent.fashion/buscar/{titulo_busqueda.replace(' ', '%20')}"
#     response = requests.get(url_busqueda)
    
#     if response.status_code == 200:
#         soup = BeautifulSoup(response.text, 'html.parser')
#         resultados = []
                
#         for span in soup.find_all('p'):
#             link = span.find('a', href=True)
#             if link:
#                 serie_url = link['href']
#                 serie_titulo = link.get_text().strip()

#                 if not serie_url.startswith('http'):
#                     serie_url = f"https://dontorrent.fashion{serie_url}"
                
#                 imagen_url = obtener_imagen_de_serie(serie_url)

#                 resultados.append({
#                     'titulo': serie_titulo,
#                     'url': serie_url,
#                     'imagen': imagen_url,  
#                 })
#         if not resultados:
#             resultados.append({
#                 'titulo': "Sin resultados",
#                 'url': "",
#                 'imagen': "",  
#             })

#         return resultados
#     else:
#         print("Error al realizar la búsqueda:", response.status_code)
#         return []

# def obtener_imagen_de_serie(serie_url):
#     """Obtiene la imagen de la serie desde su página individual."""
    
#     response = requests.get(serie_url)
    
#     if response.status_code == 200:
#         soup = BeautifulSoup(response.text, 'html.parser')
        
#         imagen = soup.find('img', {'class': 'img-thumbnail'})  
    
#         return urljoin(serie_url, imagen['src'])  


# from concurrent.futures import ThreadPoolExecutor


# def procesar_pagina(page, dialog):
#     """Procesa cada página y muestra el progreso en el cuadro de diálogo."""
#     dialog.update(int((page / 840) * 100), f"Buscando página {page}/840...")
    
#     url = f"https://dontorrent.fashion/series/letra-./page/{page}"
#     response = requests.get(url)
    
#     series = []
#     if response.status_code == 200:
#         soup = BeautifulSoup(response.text, 'html.parser')
        
#         for p in soup.find_all('p'):
#             link = p.find('a', href=True)
#             if link and link['href'].startswith('/serie/'):
#                 serie_url = link['href']
#                 serie_titulo = link.get_text().strip()
#                 series.append({
#                     'titulo': serie_titulo,
#                     'url': f"https://dontorrent.fashion{serie_url}",
#                     'page': page  
#                 })
#     return series

# def all_series():
#     series = []
    
#     dialog = xbmcgui.DialogProgress()
#     dialog.create("Buscando series", "Cargando páginas...")
#     try:
#         with ThreadPoolExecutor(max_workers=20) as executor:
#             paginas = range(1, 840)  
#             resultados = list(executor.map(lambda page: procesar_pagina(page, dialog), paginas))
        
#         for resultado in resultados:
#             series.extend(resultado)

#         series.sort(key=lambda x: x['page'])

#         series_unicas = []
#         seen_urls = set()
#         for serie in series:
#             if serie['url'] not in seen_urls:
#                 seen_urls.add(serie['url'])
#                 del serie['page']
#                 series_unicas.append(serie)
#     finally:
#         dialog.close()

#     return series_unicas


# def buscar_series(titulo):
#     series = all_series()
    
#     titulo = titulo.lower()
#     series_encontradas = [
#         serie for serie in series if titulo in serie['titulo'].lower()
#     ]
#     return series_encontradas

import requests
import xbmcgui
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import json
import re
from datetime import datetime


def mostrar_notificacion(titulo, mensaje, duracion=3000):
    xbmcgui.Dialog().notification(titulo, mensaje, time=duracion, sound=False)
    # print(mensaje)


# Ruta para guardar el archivo JSON con las series
SERIES_JSON_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "series_data.json")


def obtener_datos_serie(series_url):
    """Obtiene el título y la descripción de una serie a partir de su URL."""
    series_response = requests.get(series_url)
    series_soup = BeautifulSoup(series_response.content, "html.parser")
    
    title_tag = series_soup.find("h2", class_="descargarTitulo")
    title = title_tag.get_text(strip=True) if title_tag else ""
    title = title.replace("Descargar ", "").replace(" por Torrent", "").strip()
    
    description_tag = series_soup.find("p", class_="text-justify")
    description = ""
    if description_tag and description_tag.find("b", class_="bold").get_text(strip=True) == "Descripción:":
        description = description_tag.get_text(strip=True).replace("Descripción:", "").strip()

    image_tag = series_soup.find("img", class_="img-thumbnail")
    image_url = urljoin(series_url, image_tag['src'])

    return title, description,image_url

def obtener_series(pagina=1):
    """Obtiene el listado de series desde el archivo JSON y luego extrae la información de cada URL."""
    # mostrar_notificacion("Actualizando lista", "Cargando series desde el archivo JSON...", 3000)
    
    # Leer el archivo JSON que contiene la lista de series
    if not os.path.exists(SERIES_JSON_PATH):
        mostrar_notificacion("No hay series disponibles", "Debes cargarlas primero", 1000)
        return []
    
    with open(SERIES_JSON_PATH, 'r', encoding='utf-8') as f:
        all_series = json.load(f)
    
    # Dividir las series en páginas (por ejemplo, si hay 1000 series, 50 por página)
    series_por_pagina = 50
    inicio = (pagina - 1) * series_por_pagina
    fin = inicio + series_por_pagina
    
    # Obtener las series correspondientes a la página
    series_pagina = all_series[inicio:fin]
    
    series_completas = []
    
    # Usar ThreadPoolExecutor para obtener la información de cada serie de manera concurrente
    with ThreadPoolExecutor(max_workers=20) as executor:
        future_to_url = {
            executor.submit(obtener_datos_serie, serie['url']): serie['url']
            for serie in series_pagina
        }
        
        for future in as_completed(future_to_url):
            try:
                # Obtener los detalles de la serie
                title, description, image_url = future.result()
                
                if title:  # Si se encontró el título, agregar la serie a la lista
                    series_completas.append({
                        "titulo": title,
                        "descripcion": description,
                        "imagen": image_url,
                        "url": future_to_url[future]  # Guardar la URL original
                    })
            except Exception as e:
                print(f"Error procesando la URL: {future_to_url[future]} - {e}")

    return series_completas

def buscar_series(titulo):
    """Busca series en el archivo JSON que contengan el título proporcionado."""

    # Leer el archivo JSON que contiene la lista de series
    if not os.path.exists(SERIES_JSON_PATH):
        print("El archivo JSON de series no existe.")
        return []
    
    with open(SERIES_JSON_PATH, 'r', encoding='utf-8') as f:
        all_series = json.load(f)

    # Filtrar las series que contienen el título buscado (insensible a mayúsculas/minúsculas)
    series_encontradas = [
        serie for serie in all_series if titulo.lower() in serie['titulo'].lower()
    ]
    
    # Si no hay resultados, mostrar un mensaje
    if not series_encontradas:
        print(f"No se encontraron series que coincidan con: {titulo}")
        return []
    
    # Devolver las series encontradas
    series_completas = []
    
    # Usar ThreadPoolExecutor para obtener la información de cada serie de manera concurrente
    with ThreadPoolExecutor(max_workers=20) as executor:
        future_to_url = {
            executor.submit(obtener_datos_serie, serie['url']): serie['url']
            for serie in series_encontradas
        }
        
        for future in as_completed(future_to_url):
            try:
                # Obtener los detalles de la serie
                title, description, image_url = future.result()

                if title:  # Si se encontró el título, agregar la serie a la lista
                    series_completas.append({
                        "titulo": title,
                        "descripcion": description or "Descripción no disponible",
                        "imagen": image_url or "Imagen no disponible",
                        "url": future_to_url[future]  # Guardar la URL original
                    })
            except Exception as e:
                print(f"Error procesando la URL: {future_to_url[future]} - {e}")

    return series_completas

def obtener_episodios_serie(series_url):
    """Obtiene la lista de episodios de una serie específica."""
    series_response = requests.get(series_url)
    series_soup = BeautifulSoup(series_response.content, "html.parser")
    
    episodes = []
    episode_table = series_soup.find("table")  
    if episode_table:
        for row in episode_table.find_all("tr"):
            cells = row.find_all("td")
            if len(cells) >= 3:  
                episode = cells[0].get_text(strip=True) 
                
                download_link = cells[1].find("a")["href"] if cells[1].find("a") else ""
                if download_link and not download_link.startswith("http"):
                    download_link = f"https://{download_link.lstrip('/')}"

                date = cells[2].get_text(strip=True)  # Fecha del episodio

                episodes.append({
                    "capitulo": f"{episode}",
                    "enlace_descarga": download_link,
                    "fecha": date
                })

    return episodes

def procesar_pagina(page, dialog, ultima_pagina_series):
    """Procesa cada página y muestra el progreso en el cuadro de diálogo."""
    dialog.update(int((page / ultima_pagina_series) * 100), f"Buscando series, {int((page / ultima_pagina_series) * 100)} %")

    url = f"https://dontorrent.fashion/series/letra-./page/{page}"
    response = requests.get(url)
    
    series = []
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        
        for p in soup.find_all('p'):
            link = p.find('a', href=True)
            if link and link['href'].startswith('/serie/'):
                serie_url = link['href']
                serie_titulo = link.get_text().strip()
                series.append({
                    'titulo': serie_titulo,
                    'url': f"https://dontorrent.fashion{serie_url}",
                    'page': page
                })
    
    return series

def encontrar_ultima_pagina_series(pagina):
    url_pagina = f"https://dontorrent.fashion/series/letra-./page/{pagina}"
    
    try:
        response = requests.get(url_pagina, timeout=5)  # Reducir tiempo de espera
        response.raise_for_status()  # Para manejar errores HTTP (como 404 o 500)
        
        soup = BeautifulSoup(response.content, 'html.parser')
        disabled_items = soup.find_all('li', class_='page-item disabled')

        for item in disabled_items:
            a_tag = item.find('a', string='Siguiente')
            if a_tag:
                return pagina

    except (requests.RequestException, Exception) as e:
        return None  # Ignorar errores y continuar

    return None  # No encontrado

def encontrar_siguiente_pagina_series():
    pagina = 835
    with ThreadPoolExecutor(max_workers=10) as executor:  # Usa múltiples hilos
        while True:
            # Ejecutar las peticiones de forma concurrente
            futures = [executor.submit(encontrar_ultima_pagina_series, pagina + i) for i in range(10)]
            results = [future.result() for future in futures]

            # Buscar el resultado
            for result in results:
                if result:
                    # print(result)
                    return  result

            # Incrementar el número de página para la siguiente iteración
            # print(f"No encontrado en las páginas {pagina} - {pagina+9}. Avanzando.")
            pagina += 10

# Llamar a la función


def all_series():
    """Obtiene todas las series, las procesa, y las guarda en un archivo JSON."""
    series = []
    ultima_pagina_series = encontrar_siguiente_pagina_series()
    dialog = xbmcgui.DialogProgress()
    dialog.create("Buscando series", "Espera...")
    try:
        with ThreadPoolExecutor(max_workers=20) as executor:
            paginas = range(1, ultima_pagina_series)  # Aquí es donde defines cuántas páginas quieres procesar
            resultados = list(executor.map(lambda page: procesar_pagina(page, dialog, ultima_pagina_series), paginas))
        
        for resultado in resultados:
            series.extend(resultado)

        # Ordenar las series por el número de página
        series.sort(key=lambda x: x['page'])

        # Eliminar duplicados basados en la URL
        series_unicas = []
        seen_urls = set()
        for serie in series:
            if serie['url'] not in seen_urls:
                # Filtrar series con títulos no deseados
                if re.match(r"^\s*-.*Temporada", serie['titulo'].strip()):
                    continue

                seen_urls.add(serie['url'])
                del serie['page']  # Eliminar la clave 'page' porque ya no es necesaria
                series_unicas.append(serie)
        
        # Guardar las series únicas en un archivo JSON
        total_series = len(series_unicas)
        mostrar_notificacion("Terminado", f"Carga de {total_series} series completada y guardada", 3000)
        
        with open(SERIES_JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(series_unicas, f, ensure_ascii=False, indent=4)
            
    finally:
        dialog.close()
        
    return series_unicas


# all_series()