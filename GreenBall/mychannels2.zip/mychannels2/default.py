import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import requests
import urllib.parse
import difflib 
from search_canales import cargar_enlaces_desde_json
from update_list import actualizar_lista, actualizar_lista2, actualizar_lista3 # Importar la función para actualizar la lista
from directos import get_tv_programs, find_closest_channel  # Importa find_closest_channel de directos
from tdt import obtener_canales_tdt
from directos2 import obtener_eventos
from links_cine import obtener_eventos_nuevos, search_movies
from links_series import obtener_series, obtener_episodios_serie, buscar_series, obtener_imagen_de_serie

def mostrar_notificacion(titulo, mensaje, duracion=3000):
    xbmcgui.Dialog().notification(titulo, mensaje, time=duracion, sound=False)

# Constants
ADDON = xbmcaddon.Addon()
PLUGIN_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

class KodiAddonWrapper:
    def __init__(self):
        self.handle = HANDLE
        self.plugin_url = PLUGIN_URL

    def show_main_menu(self):
        """Display the main menu with options."""
        main_options = ["TDT", "Directos", "Directos 2 (lista propia)", "Canales", "Actualizar lista","Actualizar lista opcion 2", "Cine", "Series"]
        for option in main_options:
            list_item = xbmcgui.ListItem(label=option)
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=f"{self.plugin_url}?action={option.lower().replace(' ', '_')}",
                listitem=list_item,
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(self.handle)

    def mostrar_canales_tdt(self):
        canales = obtener_canales_tdt()
        if not canales:
            xbmcgui.Dialog().notification("Error", "No se pudieron cargar los canales de TDT.", xbmcgui.NOTIFICATION_ERROR)
            return
        
        for canal in canales:
            if canal["url"]:
                list_item = xbmcgui.ListItem(label=canal["name"])
                list_item.setArt({'thumb': canal["logo"]})
                list_item.setInfo("video", {"title": canal["name"]})
                url = canal["url"]  # Link directo para la reproducción
                xbmcplugin.addDirectoryItem(
                    handle=self.handle, 
                    url=url, 
                    listitem=list_item, 
                    isFolder=False,
                )

        xbmcplugin.endOfDirectory(self.handle)
    
    def show_directos(self):
        """Display live events with their associated channels, grouped by date."""
        canales_url = "https://actualsebastian.vercel.app/base.txt"
        links, names = cargar_enlaces_desde_json()

        if not links or not names:
            links, names = actualizar_lista3(canales_url)

        # Obtener los eventos deportivos
        channel_map = {"names": names, "links": links}
        eventos = get_tv_programs(channel_map=channel_map)

        # Agrupar eventos por fecha
        eventos_por_fecha = {}
        for evento in eventos:
            
            # Agregar el evento a la lista de esa fecha
            if evento.day not in eventos_por_fecha:
                eventos_por_fecha[evento.day] = []
            eventos_por_fecha[evento.day].append(evento)  # Guardamos el objeto Event, no una tupla

        # Definir los deportes que queremos mostrar
        deportes_validos = ["Fútbol", "Fórmula 1", "Motos"]

        # Mostrar los eventos en el menú, agrupados por fecha
        for fecha, eventos_lista in eventos_por_fecha.items():
            # Enviar la fecha como un "comentario" sin enlace, con color amarillo
            list_item_fecha = xbmcgui.ListItem(label=f"[COLOR yellow]{fecha}[/COLOR]")
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url="#",  # No tiene enlace, es solo un comentario
                listitem=list_item_fecha,
                isFolder=False
            )

            # Mostrar cada evento de esa fecha con su hora
            for evento in eventos_lista:
                hora = evento.time
                nombre_evento = evento.name
                canal = evento.channel
                tipoevento = evento.sport
                closest_channel = find_closest_channel(canal, names)

                # Filtrar los eventos por los deportes válidos
                if evento.sport not in deportes_validos:
                    continue  # Si el deporte no es válido, omitir el evento

                # Si hay enlace
                if closest_channel:
                    idx = names.index(closest_channel)
                    acestream_link = links[idx]
                    # Incluir la hora, nombre del evento y canal en el label
                    list_item = xbmcgui.ListItem(label=f"{hora} - {nombre_evento} - {canal} - {tipoevento}")
                    list_item.setInfo("video", {"title": f"{nombre_evento} - {tipoevento}"})
                    list_item.setProperty("IsPlayable", "true")

                    xbmcplugin.addDirectoryItem(
                        handle=self.handle,
                        url=f"plugin://script.module.horus?action=play&id={acestream_link}",
                        listitem=list_item,
                        isFolder=False
                    )

            # Si no hay eventos válidos (sin enlace o sin deporte válido), no se añaden al menú.
            # No es necesario mostrar nada si no se encuentra enlace o si el deporte es inválido.

        xbmcplugin.endOfDirectory(self.handle)

    def show_directos2(self):
        """Display live events extracted from the specified URL."""
        eventos = obtener_eventos()  # Llama a la función para obtener los eventos

        # Agrupar eventos por hora
        eventos_por_hora = {}
        for evento in eventos:
            # Agregar el evento a la lista de esa hora
            if evento['hora'] not in eventos_por_hora:
                eventos_por_hora[evento['hora']] = []
            eventos_por_hora[evento['hora']].append(evento)

        # Mostrar los eventos en el menú, agrupados por hora
        for hora, eventos_lista in eventos_por_hora.items():
            # Enviar la hora como un "comentario"
            list_item_hora = xbmcgui.ListItem(label=f"[COLOR yellow]{hora}[/COLOR]")
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url="#",  # No tiene enlace, es solo un comentario
                listitem=list_item_hora,
                isFolder=False
            )

            # Mostrar cada evento de esa hora
            for evento in eventos_lista:
                nombre_evento = evento['evento']
                equipos_deportistas = evento['equipos_deportistas']
                enlaces_acestream = evento['enlaces_acestream']

                # Mostrar todos los enlaces disponibles
                for i, acestream_link in enumerate(enlaces_acestream):
                    # Eliminar el prefijo
                    acestream_link = acestream_link.replace("acestream://", "")
                    # Incluir el nombre del evento, equipos y el índice en el label para diferenciarlos
                    list_item = xbmcgui.ListItem(label=f"{nombre_evento} - {equipos_deportistas} - Enlace {i + 1}")
                    list_item.setInfo("video", {"title": f"{nombre_evento} - {equipos_deportistas}"})
                    list_item.setProperty("IsPlayable", "true")

                    xbmcplugin.addDirectoryItem(
                        handle=self.handle,
                        url=f"plugin://script.module.horus?action=play&id={acestream_link}",  # Usar el ID sin el prefijo
                        listitem=list_item,
                        isFolder=False
                    )

        xbmcplugin.endOfDirectory(self.handle)
        
    def show_canales(self):
        """Display the Canales menu."""
        canales_url = "https://actualsebastian.vercel.app/base.txt" 
        links, names = cargar_enlaces_desde_json()

        if not links or not names:
            # Si no hay enlaces, busca y guarda en JSON
            links, names = actualizar_lista3(canales_url)

        # Mostrar los canales en el menú
        for idx, (name, link) in enumerate(zip(names, links), start=1):
            list_item = xbmcgui.ListItem(label=name)
            list_item.setInfo("video", {"title": name})  # Añadir información sobre el video
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=f"plugin://script.module.horus?action=play&id={link}",  # URL para reproducir
                listitem=list_item,
                isFolder=False,
            )
        
        xbmcplugin.endOfDirectory(self.handle)

    def update_list(self):
        """Update the list of channels."""
        canales_url = "https://actualsebastian.vercel.app/base.txt"  
        links, names = actualizar_lista3(canales_url)  # Llamar a la función para actualizar la lista

    def update_list2(self):
        """Update the list of channels."""
        canales_url = "https://www.robertofreijo.com/acestream-ids/"  
        links, names = actualizar_lista2(canales_url)  # Llamar a la función para actualizar la lista

    # def update_list3(self):
    #     """Update the list of channels."""
    #     canales_url = "https://actualsebastian.vercel.app/base.txt"  
    #     links, names = actualizar_lista3(canales_url)  # Llamar a la función para actualizar la lista


    

    def mostrar_nuevas(self, pagina=1):
        """Display new events with their associated links and images."""

        # Agregar un enlace para buscar por título
        buscar_item = xbmcgui.ListItem(label="BUSCAR POR TITULO")
        buscar_url = f"{sys.argv[0]}?action=buscar_titulo"
        xbmcplugin.addDirectoryItem(
            handle=self.handle,
            url=buscar_url,
            listitem=buscar_item,
            isFolder=True
        )

        eventos_nuevos = obtener_eventos_nuevos(pagina)  

        for evento in eventos_nuevos:
            nombre_evento = evento['titulo']
            enlace = evento['enlace_descarga']
            url_imagen = evento['imagen']
            descripcion = evento.get('descripcion', "Descripción no disponible.")  #descripción

            # Crear el ListItem para Kodi
            list_item = xbmcgui.ListItem(label=nombre_evento)
            list_item.setArt({'thumb': url_imagen})  # Establecer la imagen
            list_item.setInfo("video", {
                "title": nombre_evento,
                "plot": descripcion  # Añadir la descripción 
            })
            list_item.setProperty("IsPlayable", "true")  # Marcarlo como reproducible

            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=f"plugin://plugin.video.elementum/play?uri={enlace}",  # enlace de descarga para reproducir
                listitem=list_item,
                isFolder=False
            )

        # Agregar el enlace para mostrar más resultados
        if pagina < 51:  
            next_page_url = f"{sys.argv[0]}?action=cine&pagina={pagina + 1}"
            next_page_item = xbmcgui.ListItem(label="MOSTRAR MÁS RESULTADOS")
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=next_page_url,
                listitem=next_page_item,
                isFolder=True
            )

        xbmcplugin.endOfDirectory(self.handle)

    def buscar_titulo(self):
        """Función para buscar películas por título."""
        # Solicitar al usuario que introduzca un título
        dialog = xbmcgui.Dialog()
        titulo = dialog.input("Ingrese el título de la película:")

        if titulo:  
            
            eventos_nuevos = search_movies(titulo)  
            
            for evento in eventos_nuevos:
                nombre_evento = evento['titulo']
                enlace = evento['enlace_descarga']
                url_imagen = evento['imagen']
                descripcion = evento.get('descripcion', "Descripción no disponible.")  

                # Crear el ListItem para Kodi
                list_item = xbmcgui.ListItem(label=nombre_evento)
                list_item.setArt({'thumb': url_imagen})  
                list_item.setInfo("video", {
                    "title": nombre_evento,
                    "plot": descripcion  
                })
                list_item.setProperty("IsPlayable", "true")  

                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=f"plugin://plugin.video.elementum/play?uri={enlace}",  
                    listitem=list_item,
                    isFolder=False
                )

            xbmcplugin.endOfDirectory(self.handle)

    def mostrar_episodios(self, series_url):
        """Muestra los episodios de una serie específica en el addon de Kodi."""
        episodios = obtener_episodios_serie(series_url)

        for episodio in episodios:
            nombre_episodio = episodio['capitulo']
            enlace_descarga = episodio['enlace_descarga']
            fecha = episodio['fecha']
            
            # Crear el ListItem para Kodi
            list_item = xbmcgui.ListItem(label=nombre_episodio)
            list_item.setInfo("video", {
                "title": nombre_episodio,
                "plot": f"Fecha: {fecha}"  
            })
            list_item.setProperty("IsPlayable", "true")  

            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=f"plugin://plugin.video.elementum/play?uri={enlace_descarga}",  
                listitem=list_item,
                isFolder=False
            )

        xbmcplugin.endOfDirectory(self.handle)

    def mostrar_series(self, pagina=1):
        """Muestra las series con sus imágenes y descripciones en el addon de Kodi."""
        buscar_item = xbmcgui.ListItem(label="BUSCAR POR TITULO")
        buscar_url = f"{sys.argv[0]}?action=buscar_titulo_serie"
        xbmcplugin.addDirectoryItem(
            handle=self.handle,
            url=buscar_url,
            listitem=buscar_item,
            isFolder=True
        )

        series = obtener_series(pagina)  

        for serie in series:
            nombre_serie = serie['titulo']
            url_imagen = serie['imagen']
            descripcion = serie.get('descripcion', "Descripción no disponible.")
            url_serie = f"{sys.argv[0]}?action=mostrar_episodios&url={serie['url']}" 
            
            
            list_item = xbmcgui.ListItem(label=nombre_serie)
            list_item.setArt({'thumb': url_imagen, 'icon': url_imagen, 'fanart': url_imagen})
            list_item.setInfo("video", {
                "title": nombre_serie,
                "plot": descripcion
            })

            
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url_serie,
                listitem=list_item,
                isFolder=True  
            )

       
        if pagina < 201:  # Límite de páginas
            next_page_url = f"{sys.argv[0]}?action=series&pagina={pagina + 1}"
            next_page_item = xbmcgui.ListItem(label="MOSTRAR MÁS RESULTADOS")
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=next_page_url,
                listitem=next_page_item,
                isFolder=True
            )

        xbmcplugin.endOfDirectory(self.handle)

    def buscar_titulo_serie(self):
        """Función para buscar series por título."""
        dialog = xbmcgui.Dialog()
        titulo = dialog.input("Ingrese el título de la serie:")
        
        if titulo: 
            resultados = buscar_series(titulo)
            mostrar_notificacion("Actualizando lista, espera a que termine", "Obteniendo datos...", 40000)
            
            for serie in resultados:
                nombre_serie = serie['titulo']
                url_imagen = obtener_imagen_de_serie(serie['url'])
                descripcion = serie.get('descripcion', "Descripción no disponible.")
                url_serie = f"{sys.argv[0]}?action=mostrar_episodios&url={serie['url']}"

                
                list_item = xbmcgui.ListItem(label=nombre_serie)
                list_item.setArt({'thumb': url_imagen, 'icon': url_imagen, 'fanart': url_imagen})
                list_item.setInfo("video", {
                    "title": nombre_serie,
                    "plot": descripcion
                })

                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url_serie,
                    listitem=list_item,
                    isFolder=True
                )

            
            mostrar_notificacion("Terminado", "Mostrando lista", 1000)
            xbmcplugin.endOfDirectory(self.handle)
    
    
    def buscar_titulo(self):
        """Función para buscar películas por título."""
        
        dialog = xbmcgui.Dialog()
        titulo = dialog.input("Ingrese el título de la película:")

        if titulo:  
            eventos_nuevos = search_movies(titulo) 

            for evento in eventos_nuevos:
                nombre_evento = evento['titulo']
                enlace = evento['enlace_descarga']
                url_imagen = evento['imagen']
                descripcion = evento.get('descripcion', "Descripción no disponible.")  

                # Crear el ListItem para Kodi
                list_item = xbmcgui.ListItem(label=nombre_evento)
                list_item.setArt({'thumb': url_imagen})  
                list_item.setInfo("video", {
                    "title": nombre_evento,
                    "plot": descripcion  
                })
                list_item.setProperty("IsPlayable", "true")  

                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=f"plugin://plugin.video.elementum/play?uri={enlace}", 
                    listitem=list_item,
                    isFolder=False
                )

            xbmcplugin.endOfDirectory(self.handle)
            
    def run(self):
        """Run the addon by handling the current action."""
        # Parse query parameters
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get("action")
        
        if action == "directos":
            self.show_directos()
        elif action == "directos_2_(lista_propia)":
            self.show_directos2()
        elif action == "cine":  
            pagina = int(params.get("pagina", 1))  
            self.mostrar_nuevas(pagina)
        elif action == "series":  
            pagina = int(params.get("pagina", 1))  
            self.mostrar_series(pagina)
        elif action == 'mostrar_episodios':
            url = params.get('url')
            self.mostrar_episodios(url)
        elif action == 'buscar_titulo':
            self.buscar_titulo()
        elif action == 'buscar_titulo_serie':
            self.buscar_titulo_serie()
        elif action == "tdt":
            self.mostrar_canales_tdt()
        elif action == "canales":
            self.show_canales()
        elif action == "actualizar_lista":
            self.update_list()
            xbmcgui.Dialog().notification("Info", "Lista actualizada exitosamente.")
        elif action == "actualizar_lista_opcion_2":
            self.update_list2()
            xbmcgui.Dialog().notification("Info", "Lista actualizada exitosamente.")
        # elif action == "actualizar_lista_opcion_3":
        #     self.update_list3()
        #     xbmcgui.Dialog().notification("Info", "Lista actualizada exitosamente.")
        else:
            self.show_main_menu()


def main():
    addon = KodiAddonWrapper()
    addon.run()


if __name__ == "__main__":
    main()
