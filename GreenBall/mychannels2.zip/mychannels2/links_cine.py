import requests
from bs4 import BeautifulSoup
import xbmcgui
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed

def mostrar_notificacion(titulo, mensaje, duracion=3000):
    xbmcgui.Dialog().notification(titulo, mensaje, time=duracion, sound=False)

def obtener_datos_pelicula(movie_url):
    """Función para obtener los detalles de una película."""
    movie_response = requests.get(movie_url)
    movie_soup = BeautifulSoup(movie_response.content, "html.parser")
    
    # Intentar extraer el título de la película
    title_tag = movie_soup.find("h1", class_="descargarTitulo")
    title = title_tag.get_text(strip=True) if title_tag else ""
    title = title.replace("Descargar ", "").replace("   por Torrent", "").strip()

    # Extraer el año de la película
    year_tag = title_tag.find_next("p", class_="m-1") if title_tag else None
    year = year_tag.get_text(strip=True) if year_tag else ""

    # Extraer la descripción de la película
    description_tag = movie_soup.find("p", class_="text-justify")
    description = ""
    if description_tag and description_tag.find("b", class_="bold").get_text(strip=True) == "Descripción:":
        description = description_tag.get_text(strip=True).replace("Descripción:", "").strip()
    
    # Concatenar el año con el título, si se encontró
    full_title = f"{title} ({year})" if year else title

    # Intentar extraer el enlace de descarga
    download_link = movie_soup.find("a", id="download_torrent")
    download_url = download_link.get("href") if download_link else ""
    
    return full_title, download_url, description



def obtener_eventos_nuevos(pagina=1):
    # URL principal
    mostrar_notificacion("Actualizando lista, espera a que termine", "Buscando peliculas...", 3000)

    base_url = "https://dontorrent.fashion"
    eventos_nuevos = []

    # Generar la URL de la página actual
    url = f"{base_url}/peliculas/page/{pagina}"
    
    # Realizar la solicitud a la URL de la página actual
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    # Encontrar todos los enlaces <a> que contienen una imagen <img>
    links = [(link['href'], urljoin("https:", link.find("img")["src"])) 
             for link in soup.find_all("a", href=True) if link.find("img")]

    # Usar ThreadPoolExecutor para manejar las solicitudes concurrentes
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_url = {executor.submit(obtener_datos_pelicula, urljoin(base_url, href)): (href, img_src) for href, img_src in links}
        
        for future in as_completed(future_to_url):
            href, img_src = future_to_url[future]
            try:
                title, download_url, description = future.result()
                if title:  # Asegúrate de que el título no esté vacío
                    eventos_nuevos.append({
                        "titulo": title,
                        "imagen": img_src,
                        "descripcion": description,
                        "enlace_descarga": urljoin(base_url, download_url) if download_url else ""
                    })
            except Exception as e:
                print(f"Error procesando {href}: {e}")

    return eventos_nuevos

def buscar_peliculas(titulo_busqueda):
    # URL del endpoint de búsqueda
    mostrar_notificacion("Actualizando lista, espera a que termine", "Buscando pelicula...", 3000)
    url = "https://dontorrent.fashion/peliculas/buscar"
    
    # Datos para la solicitud POST
    data = {
        "campo": "titulo",
        "valor": titulo_busqueda
    }

    # Realiza la solicitud POST
    response = requests.post(url, data=data)

    # Verifica el estado de la respuesta
    if response.status_code != 200:
        print(f"Error en la solicitud: {response.status_code}")
        return []

    # Procesar la respuesta
    soup = BeautifulSoup(response.content, "html.parser")

    # Lista para almacenar los eventos de películas
    peliculas = []

    # Encontrar todos los enlaces de películas en los resultados
    for link in soup.find_all("a", href=True):
        # Asegúrate de que el enlace de película esté en el formato correcto
        if "pelicula" in link['href']:  # Filtrar enlaces relevantes
            img_src = link.find("img")["src"] if link.find("img") else ""
            peliculas.append((urljoin("https://dontorrent.fashion", link['href']), urljoin("https:", img_src)))

    return peliculas

def search_movies(titulo_busqueda):
    peliculas_encontradas = buscar_peliculas(titulo_busqueda)
    
    eventos_nuevos = []
    base_url = "https://dontorrent.fashion"

    # Usar ThreadPoolExecutor para manejar las solicitudes concurrentes
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_data = {
            executor.submit(obtener_datos_pelicula, url): (url, img_src) 
            for url, img_src in peliculas_encontradas
        }
        
        for future in as_completed(future_to_data):
            url, img_src = future_to_data[future]
            try:
                title, download_url, descripcion = future.result()  # Asegúrate de que obtener_datos_pelicula devuelva la descripción
                if title:  # Asegúrate de que el título no esté vacío
                    eventos_nuevos.append({
                        "titulo": title,
                        "imagen": img_src,
                        "enlace_descarga": urljoin(base_url, download_url) if download_url else "",
                        "descripcion": descripcion  # Añadir la descripción a la lista de eventos nuevos
                    })
            except Exception as e:
                print(f"Error procesando {url}: {e}")

    return eventos_nuevos  # Devuelve la lista de eventos nuevos

# titulo_busqueda = "saw"
# resultados = search_movies(titulo_busqueda)

# for pelicula in resultados:
#     print(f"Título: {pelicula['titulo']}, Imagen: {pelicula['imagen']}, Enlace de descarga: {pelicula['enlace_descarga']}, Descripcion: {pelicula['descripcion']}")