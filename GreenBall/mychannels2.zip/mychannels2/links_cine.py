import requests
import xbmcgui
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import json
import re


def mostrar_notificacion(titulo, mensaje, duracion=3000):
    xbmcgui.Dialog().notification(titulo, mensaje, time=duracion, sound=False)
    # print(mensaje)


# Ruta para guardar el archivo JSON con las pelis
pelis_JSON_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pelis_data.json")


def obtener_datos_peli(pelis_url):
    """Obtiene el título y la descripción de una peli a partir de su URL."""
    pelis_response = requests.get(pelis_url)
    pelis_soup = BeautifulSoup(pelis_response.content, "html.parser")
    
    title_tag = pelis_soup.find("h1", class_="descargarTitulo")
    title = title_tag.get_text(strip=True) if title_tag else ""
    title = title.replace("Descargar ", "").replace(" por Torrent", "").strip()
    
    year_tag = pelis_soup.find("p", class_="m-1")
    year_tag = year_tag.find("a").get_text()
    # print(year_tag)
    title = f"{title} - [{year_tag}]"  # Añadir el año al título
    
    description_tag = pelis_soup.find("p", class_="text-justify")
    description = ""
    if description_tag and description_tag.find("b", class_="bold").get_text(strip=True) == "Descripción:":
        description = description_tag.get_text(strip=True).replace("Descripción:", "").strip()

    image_tag = pelis_soup.find("img", class_="img-thumbnail")
    image_url = urljoin(pelis_url, image_tag['src'])

    download_link = pelis_soup.find("a", id="download_torrent")
    download_url = download_link.get("href") if download_link else ""

    # Corregir download_url si empieza con "//"
    if download_url.startswith("//"):
        download_url = "https:" + download_url

    return title, description, image_url, download_url

def obtener_pelis(pagina=1):
    """Obtiene el listado de pelis desde el archivo JSON y luego extrae la información de cada URL."""
    # mostrar_notificacion("Actualizando lista", "Cargando pelis desde el archivo JSON...", 3000)
    
    # Leer el archivo JSON que contiene la lista de pelis
    if not os.path.exists(pelis_JSON_PATH):
        mostrar_notificacion("No hay pelis disponibles", "Debes cargarlas primero", 1000)
        return []
    
    with open(pelis_JSON_PATH, 'r', encoding='utf-8') as f:
        all_pelis = json.load(f)
    
    # Dividir las pelis en páginas (por ejemplo, si hay 1000 pelis, 50 por página)
    pelis_por_pagina = 50
    inicio = (pagina - 1) * pelis_por_pagina
    fin = inicio + pelis_por_pagina
    
    # Obtener las pelis correspondientes a la página
    pelis_pagina = all_pelis[inicio:fin]
    
    pelis_completas = []
    
    # Usar ThreadPoolExecutor para obtener la información de cada peli de manera concurrente
    with ThreadPoolExecutor(max_workers=20) as executor:
        future_to_url = {
            executor.submit(obtener_datos_peli, peli['url']): peli['url']
            for peli in pelis_pagina
        }
        
        for future in as_completed(future_to_url):
            try:
                # Obtener los detalles de la peli
                title, description, image_url, download_url = future.result()
                
                if title:  # Si se encontró el título, agregar la peli a la lista
                    pelis_completas.append({
                        "titulo": title,
                        "descripcion": description,
                        "imagen": image_url,
                        "url": future_to_url[future],  # Guardar la URL original
                        "download_url": download_url
                    })
            except Exception as e:
                print(f"Error procesando la URL: {future_to_url[future]} - {e}")

    return pelis_completas

def buscar_pelis(titulo):
    """Busca pelis en el archivo JSON que contengan el título proporcionado."""

    # Leer el archivo JSON que contiene la lista de pelis
    if not os.path.exists(pelis_JSON_PATH):
        print("El archivo JSON de pelis no existe.")
        return []
    
    with open(pelis_JSON_PATH, 'r', encoding='utf-8') as f:
        all_pelis = json.load(f)

    # Filtrar las pelis que contienen el título buscado (insensible a mayúsculas/minúsculas)
    pelis_encontradas = [
        peli for peli in all_pelis if titulo.lower() in peli['titulo'].lower()
    ]
    
    # Si no hay resultados, mostrar un mensaje
    if not pelis_encontradas:
        print(f"No se encontraron pelis que coincidan con: {titulo}")
        return []
    
    # Devolver las pelis encontradas
    pelis_completas = []
    
    # Usar ThreadPoolExecutor para obtener la información de cada peli de manera concurrente
    with ThreadPoolExecutor(max_workers=20) as executor:
        future_to_url = {
            executor.submit(obtener_datos_peli, peli['url']): peli['url']
            for peli in pelis_encontradas
        }
        
        for future in as_completed(future_to_url):
            try:
                # Obtener los detalles de la peli
                title, description, image_url, download_url = future.result()
                if title:  # Si se encontró el título, agregar la peli a la lista
                    pelis_completas.append({
                        "titulo": title,
                        "descripcion": description,
                        "imagen": image_url,
                        "url": future_to_url[future],  # Guardar la URL original
                        "download_url": download_url
                    })
            except Exception as e:
                print(f"Error procesando la URL: {future_to_url[future]} - {e}")

    return pelis_completas


def procesar_pagina(page, dialog, ultima_pagina_pelis):
# def procesar_pagina(page, ultima_pagina_pelis):
    
    """Procesa cada página y muestra el progreso en el cuadro de diálogo."""
    dialog.update(int((page / ultima_pagina_pelis) * 100), f"Buscando pelis, {int((page / ultima_pagina_pelis) * 100)} %")

    url = f"https://dontorrent.gallery/peliculas/page/{page}"
    response = requests.get(url)
    
    pelis = []
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        # print(soup)
        for p in soup.find_all('div'):
            link = p.find('a', href=True)
            if link and link['href'].startswith('/pelicula/'):
                peli_url = link['href']
                peli_titulo = peli_url.split('/')[-1].replace("-", " ").title().strip()
                # print(f"PELI URL: {peli_url} PELI TITULO: {peli_titulo}")
                pelis.append({
                    'titulo': peli_titulo,
                    'url': f"https://dontorrent.fashion{peli_url}",
                    'page': page
                })
    
    return pelis

def encontrar_ultima_pagina_pelis(pagina):
    url_pagina = f"https://dontorrent.gallery/peliculas/page/{pagina}"
    
    try:
        response = requests.get(url_pagina, timeout=5)  # Reducir tiempo de espera
        response.raise_for_status()  # Para manejar errores HTTP (como 404 o 500)
        
        soup = BeautifulSoup(response.content, 'html.parser')
        disabled_items = soup.find_all('li', class_='page-item disabled')

        for item in disabled_items:
            a_tag = item.find('a', string='Siguiente')
            if a_tag:
                return pagina

    except (requests.RequestException, Exception) as e:
        return None  # Ignorar errores y continuar

    return None  # No encontrado

def encontrar_siguiente_pagina_pelis():
    pagina = 48
    with ThreadPoolExecutor(max_workers=10) as executor:  # Usa múltiples hilos
        while True:
            # Ejecutar las peticiones de forma concurrente
            futures = [executor.submit(encontrar_ultima_pagina_pelis, pagina + i) for i in range(10)]
            results = [future.result() for future in futures]

            # Buscar el resultado
            for result in results:
                if result:
                    print(result)
                    return  result

            # Incrementar el número de página para la siguiente iteración
            # print(f"No encontrado en las páginas {pagina} - {pagina+9}. Avanzando.")
            pagina += 10




def all_pelis():
    """Obtiene todas las pelis, las procesa, y las guarda en un archivo JSON."""
    pelis = []
    ultima_pagina_pelis = encontrar_siguiente_pagina_pelis()
    dialog = xbmcgui.DialogProgress()
    dialog.create("Buscando pelis", "Espera...")
    try:
        with ThreadPoolExecutor(max_workers=20) as executor:
            paginas = range(1, ultima_pagina_pelis)  # Aquí es donde defines cuántas páginas quieres procesar
            resultados = list(executor.map(lambda page: procesar_pagina(page, dialog, ultima_pagina_pelis), paginas))
            # resultados = list(executor.map(lambda page: procesar_pagina(page, ultima_pagina_pelis), paginas))
        
        for resultado in resultados:
            pelis.extend(resultado)

        # Ordenar las pelis por el número de página
        pelis.sort(key=lambda x: x['page'])

        # Eliminar duplicados basados en la URL
        pelis_unicas = []
        seen_urls = set()
        
        for peli in pelis:
            if peli['url'] not in seen_urls:

                seen_urls.add(peli['url'])
                del peli['page']  # Eliminar la clave 'page' porque ya no es necesaria
                pelis_unicas.append(peli)
        
        # Guardar las pelis únicas en un archivo JSON
        total_pelis = len(pelis_unicas)
        mostrar_notificacion("Terminado", f"Carga de {total_pelis} pelis completada y guardada", 3000)
        
        with open(pelis_JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(pelis_unicas, f, ensure_ascii=False, indent=4)
            
    finally:
        dialog.close()
        
    return pelis_unicas
