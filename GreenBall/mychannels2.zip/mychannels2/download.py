import requests
import xbmcgui
import os

url = 'https://dl.dropbox.com/scl/fi/wjwbd5l793qb1xpvim75l/templ?rlkey=xrcaq04qc10ukaqfmrv269bvu&st=2berpfjx&dl=0'

BD_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templ.db")

def mostrar_notificacion(titulo, mensaje, duracion=3000):
    xbmcgui.Dialog().notification(titulo, mensaje, time=duracion, sound=False)

def download_db():
    mostrar_notificacion("Descargando base de datos...", f"Por favor espere", 50000)
    # Realizamos la solicitud GET para descargar el archivo
    response = requests.get(url)

    # Comprobamos si la descarga fue exitosa
    if response.status_code == 200:
        # Nombre de archivo a guardar (añadiendo .bd al final)
        total_size = int(response.headers.get('Content-Length', 0))
        file_name = BD_PATH
        
    # Usar sys.stdout para imprimir la barra de progreso en la misma línea
        with open(file_name, 'wb') as file:
            downloaded_size = 0
            for data in response.iter_content(chunk_size=1024):
                file.write(data)  # Guardamos el bloque
                downloaded_size += len(data)  # Incrementamos el tamaño descargado
                
                # Calculamos el porcentaje
                percent = (downloaded_size / total_size) * 100
                
                # Imprimimos la barra de progreso
                
        mostrar_notificacion("Base de datos descargada", f"Completado", 3000)
    else:
        mostrar_notificacion(f"Error al descargar el archivo. Código de estado: {response.status_code}")
