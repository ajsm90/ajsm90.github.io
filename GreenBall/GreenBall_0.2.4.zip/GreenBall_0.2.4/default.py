import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import requests
import urllib.parse
import difflib 
from search_canales import obtener_acestream_links, cargar_enlaces_desde_json
from update_list import actualizar_lista, actualizar_lista2 # Importar la función para actualizar la lista
from directos import get_tv_programs, find_closest_channel  # Importa find_closest_channel de directos
import json
import xml.etree.ElementTree as ET


# Constants
ADDON = xbmcaddon.Addon()
PLUGIN_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

class KodiAddonWrapper:
    def __init__(self):
        self.handle = HANDLE
        self.plugin_url = PLUGIN_URL

    def show_main_menu(self):
        """Display the main menu with options."""
        main_options = ["Directos", "Canales", "Actualizar lista","Actualizar lista opcion 2"]
        for option in main_options:
            list_item = xbmcgui.ListItem(label=option)
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=f"{self.plugin_url}?action={option.lower().replace(' ', '_')}",
                listitem=list_item,
                isFolder=True,
            )
            # Obtener la versión actual y la última versión
            current_version = self.get_current_version()
            latest_version = self.get_latest_version()

            # Crear el mensaje de versión
            version_message = f"Versión actual: {current_version} | Última versión: {latest_version}"
            list_item_version = xbmcgui.ListItem(label=version_message)
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url="#",  # Sin enlace, solo un mensaje
                listitem=list_item_version,
                isFolder=False,
            )

        xbmcplugin.endOfDirectory(self.handle)
    def get_latest_version(self):
        """Obtener la última versión desde el archivo JSON."""
        version_url = "https://ajsm90.github.io/GreenBall/version.json"
        try:
            response = requests.get(version_url)
            response.raise_for_status()
            latest_version_info = response.json()
            return latest_version_info.get("version", "0.0.0")
        except Exception:
            return "No disponible"

    def get_current_version(self):
        """Obtener la versión actual del addon desde addon.xml."""
        addon_file = os.path.join(xbmc.translatePath("special://home/addons/plugin.video.GreenBall/"), "addon.xml") 
        try:
            tree = ET.parse(addon_file)
            root = tree.getroot()
            version = root.find("version").text
            return version
        except Exception:
            return "No disponible"
    def show_directos(self):
        """Display live events with their associated channels, grouped by date."""
        canales_url = "https://sites.google.com/view/elplandeportes/inicio"
        links, names = cargar_enlaces_desde_json()

        if not links or not names:
            links, names = obtener_acestream_links(canales_url)

        # Obtener los eventos deportivos
        channel_map = {"names": names, "links": links}
        eventos = get_tv_programs(channel_map=channel_map)

        # Agrupar eventos por fecha
        eventos_por_fecha = {}
        for evento in eventos:
            
            # Agregar el evento a la lista de esa fecha
            if evento.day not in eventos_por_fecha:
                eventos_por_fecha[evento.day] = []
            eventos_por_fecha[evento.day].append(evento)  # Guardamos el objeto Event, no una tupla

        # Definir los deportes que queremos mostrar
        deportes_validos = ["Fútbol", "Fórmula 1", "Motos"]

        # Mostrar los eventos en el menú, agrupados por fecha
        for fecha, eventos_lista in eventos_por_fecha.items():
            # Enviar la fecha como un "comentario" sin enlace, con color amarillo
            list_item_fecha = xbmcgui.ListItem(label=f"[COLOR yellow]{fecha}[/COLOR]")
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url="#",  # No tiene enlace, es solo un comentario
                listitem=list_item_fecha,
                isFolder=False
            )

            # Mostrar cada evento de esa fecha con su hora
            for evento in eventos_lista:
                hora = evento.time
                nombre_evento = evento.name
                canal = evento.channel
                closest_channel = find_closest_channel(canal, names)

                # Filtrar los eventos por los deportes válidos
                if evento.sport not in deportes_validos:
                    continue  # Si el deporte no es válido, omitir el evento

                # Si hay enlace
                if closest_channel:
                    idx = names.index(closest_channel)
                    acestream_link = links[idx]
                    # Incluir la hora, nombre del evento y canal en el label
                    list_item = xbmcgui.ListItem(label=f"{hora} - {nombre_evento} - {canal}")
                    list_item.setInfo("video", {"title": f"{nombre_evento} - {evento.sport}"})
                    list_item.setProperty("IsPlayable", "true")

                    xbmcplugin.addDirectoryItem(
                        handle=self.handle,
                        url=f"plugin://script.module.horus?action=play&id={acestream_link}",
                        listitem=list_item,
                        isFolder=False
                    )

            # Si no hay eventos válidos (sin enlace o sin deporte válido), no se añaden al menú.
            # No es necesario mostrar nada si no se encuentra enlace o si el deporte es inválido.

        xbmcplugin.endOfDirectory(self.handle)



    def show_canales(self):
        """Display the Canales menu."""
        canales_url = "https://sites.google.com/view/elplandeportes/inicio" 
        links, names = cargar_enlaces_desde_json()

        if not links or not names:
            # Si no hay enlaces, busca y guarda en JSON
            links, names = obtener_acestream_links(canales_url)

        # Mostrar los canales en el menú
        for idx, (name, link) in enumerate(zip(names, links), start=1):
            list_item = xbmcgui.ListItem(label=name)
            list_item.setInfo("video", {"title": name})  # Añadir información sobre el video
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=f"plugin://script.module.horus?action=play&id={link}",  # URL para reproducir
                listitem=list_item,
                isFolder=False,
            )
        
        xbmcplugin.endOfDirectory(self.handle)

    def update_list(self):
        """Update the list of channels."""
        canales_url = "https://sites.google.com/view/elplandeportes/inicio"  
        links, names = actualizar_lista(canales_url)  # Llamar a la función para actualizar la lista

    def update_list2(self):
        """Update the list of channels."""
        canales_url = "https://www.robertofreijo.com/acestream-ids/"  
        links, names = actualizar_lista2(canales_url)  # Llamar a la función para actualizar la lista

        
    def run(self):
        """Run the addon by handling the current action."""
        # Parse query parameters
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        action = params.get("action")
        
        if action == "directos":
            self.show_directos()
        elif action == "canales":
            self.show_canales()
        elif action == "actualizar_lista":
            self.update_list()
            xbmcgui.Dialog().notification("Info", "Lista actualizada exitosamente.")
        elif action == "actualizar_lista_opcion_2":
            self.update_list2()
            xbmcgui.Dialog().notification("Info", "Lista actualizada exitosamente.")
        else:
            self.show_main_menu()


def main():
    addon = KodiAddonWrapper()
    addon.run()


if __name__ == "__main__":
    main()
