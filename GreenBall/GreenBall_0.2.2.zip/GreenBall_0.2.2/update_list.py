import os
import json
import requests
from bs4 import BeautifulSoup
import xbmcgui

# Constants
CWD = os.path.dirname(os.path.abspath(__file__))
LINKS_FILE = os.path.join(CWD, 'acestream_links.json')

def mostrar_notificacion(titulo, mensaje, duracion=3000):
    xbmcgui.Dialog().notification(titulo, mensaje, time=duracion, sound=False)

def actualizar_lista(url):
    acestream_links = []
    link_names = []

    mostrar_notificacion("Actualizando lista, espera a que termine", "Obteniendo enlaces AceStream...", 40000)

    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')
        enlaces = soup.find_all('a', class_='QmpIrf')

        for enlace in enlaces:
            url_enlace = enlace['href']
            url_enlace_real = requests.utils.unquote(url_enlace.split('q=')[1].split('&')[0])

            if 'tinyurl.com' in url_enlace_real:
                try:
                    redirect_response = requests.get(url_enlace_real, allow_redirects=False)
                    redirected_url = redirect_response.headers.get('Location', None)
                    if redirected_url and redirected_url.startswith("acestream://"):
                        acestream_id = redirected_url.split("://")[1]
                        acestream_links.append(acestream_id)

                        nombre = enlace.find('div', class_='NsaAfc').find('p').text
                        link_names.append(nombre)
                except requests.exceptions.RequestException as e:
                    print(f"Error al acceder a {url_enlace_real}: {e}")

        # Guardar los enlaces en el archivo JSON
        with open(LINKS_FILE, 'w') as f:
            json.dump({'links': acestream_links, 'names': link_names}, f)

        mostrar_notificacion("Lista actualizada", "Búsqueda completada", 2000)

    except requests.exceptions.RequestException as e:
        mostrar_notificacion("Error", f"Error al actualizar la lista: {e}", 2000)

    return acestream_links, link_names


def actualizar_lista2(url):
    acestream_links = []
    link_names = []

    mostrar_notificacion("Actualizando lista, espera a que termine", "Obteniendo enlaces AceStream...", 40000)

    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')

        parrafos = soup.find_all(class_='et_pb_text_inner')
        segundo_parrafo = parrafos[2]  

        items = segundo_parrafo.find_all('p')
        for item in items:
            nombres = item.get_text().strip()
            
            enlace = item.find("a")
            if enlace:
                acestream_link = enlace.get_text().strip()  # Enlace AceStream
            else:
                acestream_link = ""  # Si no hay enlace, asigna cadena vacía

            # Eliminar el símbolo '•' y los espacios al principio o al final
            nombre_sin_puntos = nombres.replace('•', '').strip()
            
            if 'Enlace:' in nombre_sin_puntos:
                nombre_canal = nombre_sin_puntos.split('Enlace:')[0].strip()
            else:
                nombre_canal = nombre_sin_puntos  # Si no hay "Enlace:", se usa el nombre completo

            # Añade los valores a las listas
            
            acestream_links.append(acestream_link)
            link_names.append(nombre_canal)

        # Guardar los enlaces en el archivo JSON
        with open(LINKS_FILE, 'w') as f:
            json.dump({'links': acestream_links, 'names': link_names}, f)

        mostrar_notificacion("Lista actualizada", "Búsqueda completada", 2000)

    except requests.exceptions.RequestException as e:
        mostrar_notificacion("Error", f"Error al actualizar la lista: {e}", 2000)

    return acestream_links, link_names

